<?php


namespace Drupal\portalis_elasticsearch\Controller;


use Drupal\Core\Controller\ControllerBase;
use Drupal\elasticsearch_connector\Entity\Cluster;
use Drupal\search_api\Entity\Index;
use Drupal\search_api\IndexBatchHelper;

class TemplateController extends ControllerBase
{
  /**
   * Fonction permettant de lancer le batch de mise à jour du template elasticsearch
   */
  public function updateTemplate() {
    $batch = array(
      'operations' => array(),
      'finished' => '\Drupal\portalis_elasticsearch\Controller\TemplateController::portalisElasticsearchBatchFinished',
      'title' => 'Processing',
      'init_message' => 'Starting',
      'progress_message' => 'Processed @current out of @total.',
      'error_message' => 'Error',
    );
    $progress = 0;
    $max = 0;

    $batch['operations'][] = array('\Drupal\portalis_elasticsearch\Controller\TemplateController::portalisElasticsearchUpdateTemplateProcess', array($progress));
    $progress++;

    batch_set($batch);
    return batch_process(\Drupal::url('portalis_elasticsearch.synonym_list_route'));
  }

  /**
   * Fonction permettant d'afficher un message à la fin du batch
   */
  public static function portalisElasticsearchBatchFinished($success, $results, $operations) {
    drupal_set_message('Changement de template réussi', 'status');
  }

  /**
   * Fonction qui :
   * lance la mise à jour du template
   * reindex
   * @throws \Drupal\search_api\SearchApiException
   */
  public function portalisElasticsearchRecreerIndex() {

    //On récupère tous les clusters ES définis en BO.
    /** @var \Drupal\elasticsearch_connector\ClusterManager $cluster_manager */
    $cluster_manager = \Drupal::service('elasticsearch_connector.cluster_manager');
    $clusters = $cluster_manager->loadAllClusters(TRUE);
    //$clusters = elasticsearch_connector_clusters();
    $majIndex = 'portalisElasticsearchMajIndex';
    $templateController = new TemplateController;
    //On met à jour les index
    foreach ($clusters as $cluster) $templateController->$majIndex($cluster->cluster_id);

    $search_api_indexs = Index::loadMultiple();

    foreach ($search_api_indexs as $search_api_index) {

      $id = $search_api_index->id();
      $opIndex = Index::load($id);
      $opIndex->clear();
      $opIndex->reindex();
      /** @var \Drupal\search_api\IndexInterface $opIndex */
      IndexBatchHelper::create($opIndex, 50, -1);
     // $count = $opIndex->getTrackerInstance()->getIndexedItemsCount();
      //_search_api_batch_indexing_create($opIndex, 50, -1, $count);
    }
  }

  /**
   * fonction lancer pendant le process du batch de mise à jour du template elasticsearch
   * @throws \Drupal\search_api\SearchApiException
   */
  public function portalisElasticsearchUpdateTemplateProcess($progress, &$context) {
    TemplateController::portalisElasticsearchRecreerIndex();
    $progress++;
  }

  /**
   * Fonction qui :
   * supprime les indexs
   * supprime le template
   * crée les settings pour le nouveau template
   * ajouter le nouveau template
   * crée les indexs
   */
  public function portalisElasticsearchMajIndex($cluster_id) {
   //$client = elasticsearch_connector_get_indices_options($cluster_id);
    /** @var \Drupal\elasticsearch_connector\Entity\Cluster $elasticsearchCluster */
    $elasticsearchCluster = \Drupal::service('entity.manager')->getStorage('elasticsearch_cluster')->load($cluster_id);
    /** @var \Drupal\elasticsearch_connector\ElasticSearch\ClientManagerInterface $clientManager */
    $clientManager = \Drupal::service('elasticsearch_connector.client_manager');
    $client = $clientManager->getClientForCluster($elasticsearchCluster);

    $liste_alias = array(
      "all" => array(
        "fiches"
      ),
      "fiches_dossier" => array(
        "fiches"
      ),
      "demarches" => array(
        "formulaires"
      ),
      "suggestion" => array(

      )
    );

    foreach ($liste_alias as $alias => $index) {
      foreach ($index as $i) {
        $params = ['index' => $i, 'name' => $alias];


        $res = $client->indices()->existsAlias($params);

        if ($res == 1) {
          $response = $client->indices()->deleteAlias($params);
        }
      }
    }

    $liste_index_delete = array(
      "fiches"
    );

    foreach ($liste_index_delete as $index) {
      $params = ['index' => $index];

      $res = $client->indices()->exists($params);
      if ($res == 1) {
        $client->indices()->delete($params);
      }
    }



    $templates = array(
      "name" => "*"
    );

    $client->indices()->deleteTemplate($templates);

    $settings = array(

      "index.analysis.filter.stopwords.type" => "stop",
      "index.analysis.filter.synonym.type" => "synonym",

    );

    //synonym

    $synonym_data = db_select('elasticsearch_synonym', 'sy')
      ->fields('sy', array('id', 'term', 'synonym'))
      ->execute()->fetchAll();

    if (count($synonym_data) > 0) {

      $synonym_array = array();
      $synonym_settings = array();

      foreach ($synonym_data as $synonym) {
        $synonym_array[$synonym->synonym][] = $synonym->term;

      }

      $i=0;
      foreach ($synonym_array as $key => $value) {
        $synonym_settings['index.analysis.filter.synonym.synonyms.'.$i] = $key.' => '.$key.', '.implode(', ', $value);
        $i++;
      }

      $settings = array_merge($settings, $synonym_settings);

    }

    //stopword

    $stopword_data = db_select('elasticsearch_stopword', 'sw')
      ->fields('sw', array('id', 'stopword'))
      ->execute()->fetchAll();

    if (count($stopword_data) > 0) {
      $stopword_settings = array();

      $i=0;
      foreach ($stopword_data as $value) {
        $stopword_settings['index.analysis.filter.stopwords.stopwords.'.$i] = $value->stopword;
        $i++;
      }

      $settings = array_merge($settings, $stopword_settings);
    }

    // Importation du template.
    $template_portalis = array(
      "name" => "template_portalis",
      "body" => [
        "template" => "*",
        "settings" => $settings,
      ]
    );

    $res_template = $client->indices()->putTemplate($template_portalis);

    $liste_index_delete = array(
      "fiches"
    );

    $liste_index_create = array(
      "fiches"
    );

    foreach ($liste_index_delete as $index) {
      $params = ['index' => $index];
      $res = $client->indices()->exists($params);
      if ($res == 1) {
        $client->indices()->delete($params);
      }
    }

    foreach ($liste_index_create as $index) {
      $params = ['index' => $index];
      $res = $client->indices()->exists($params);
      if ($res != 1) {
        $client->indices()->create($params);
      }
    }



    $liste_alias_create = array(
      "all" => array(
        "fiches"
      ),
      "fiches_dossier" => array(
        "fiches"
      ),
      "demarches" => array(

      ),
      "suggestion" => array(

      )
    );

    foreach ($liste_alias_create as $alias => $index) {
      foreach ($index as $i) {
        $params = ['index' => $i, 'name' => $alias];

        $res = $client->indices()->existsAlias($params);
        if ($res == 0) {
          $client->indices()->putAlias($params);
        }
      }
    }
  }
}
