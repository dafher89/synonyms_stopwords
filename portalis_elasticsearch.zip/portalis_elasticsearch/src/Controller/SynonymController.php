<?php


namespace Drupal\portalis_elasticsearch\Controller;


use Drupal;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;

class SynonymController extends ControllerBase
{
  /**
   * Returns an administrative overview of all synonyms.
   *
   * @return array
   *   A render array representing the administrative page content.
   */
  public function synonymList() {
    //create table header
    $header_table = array(
      'id'=>    t('ID'),
      'term' => t('Le terme'),
      'synonym' => t('Ramènera des résultats concernant'),
      'opt' => t('Edit'),
      'opt1' => t('Delete'),
    );
    $query = Drupal::database()->select('elasticsearch_synonym', 'm');
    $query->fields('m', ['id','term','synonym']);
    $results = $query->execute()->fetchAll();
    $rows=array();
    foreach($results as $data){
      $delete = Url::fromUserInput('/admin/config/elasticsearch/synonym/delete/'.$data->id);
      $edit   = Url::fromUserInput('/admin/config/elasticsearch/synonym/form?num='.$data->id);

      //print the data from table
      $rows[] = array(
        'id' =>$data->id,
        'term' => $data->term,
        'synonym' => $data->synonym,

        Drupal::l('Delete', $delete),
        Drupal::l('Edit', $edit),
      );

    }
    //display data in site
    $form['table'] = [
      '#type' => 'table',
      '#header' => $header_table,
      '#rows' => $rows,
      '#empty' => t('Synonyms not found'),
    ];
    return $form;
  }

}
