<?php
/**
 * @file
 * Contains \Drupal\portalis_elasticsearch\Controller.
 */

namespace Drupal\portalis_elasticsearch\Controller;

use Drupal;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\elasticsearch_connector\ClusterManager;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\portalis_elasticsearch\Controller
 */
class StopwordController extends ControllerBase
{

    /**
     * Returns an administrative overview of all stopwords.
     *
     * @return array
     *   A render array representing the administrative page content.
     */
    public function stopwordList() {
      //create table header
      $header_table = array(
        'id'=>    t('ID'),
        'stopword' => t('Mot à exclure'),
        'opt' => t('Edit'),
        'opt1' => t('Delete'),
      );
      $query = Drupal::database()->select('elasticsearch_stopword', 'm');
      $query->fields('m', ['id','stopword']);
      $results = $query->execute()->fetchAll();
      $rows=array();
      foreach($results as $data){
        $delete = Url::fromUserInput('/admin/config/elasticsearch/stopword/delete/'.$data->id);
        $edit   = Url::fromUserInput('/admin/config/elasticsearch/stopword/form?num='.$data->id);

        //print the data from table
        $rows[] = array(
          'id' =>$data->id,
          'stopword' => $data->stopword,

          Drupal::l('Delete', $delete),
          Drupal::l('Edit', $edit),
        );

      }
      //display data in site
      $form['table'] = [
        '#type' => 'table',
        '#header' => $header_table,
        '#rows' => $rows,
        '#empty' => t('Stopwords not found'),
      ];
      return $form;
    }
}
