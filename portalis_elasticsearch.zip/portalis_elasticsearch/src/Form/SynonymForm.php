<?php


namespace Drupal\portalis_elasticsearch\Form;

use Drupal;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class SynonymForm.
 *
 * @package Drupal\portalis_elasticsearch\Form
 */
class SynonymForm extends FormBase
{

  /**
   * @inheritDoc
   */
  public function getFormId()
  {
    return 'synonym_form';
  }

  /**
   * @inheritDoc
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {
    $connexion = Database::getConnection();
    $record = array();
    if (isset($_GET['num'])) {
      $query = $connexion->select('elasticsearch_synonym', 's')
        ->condition('id',$_GET['num'])
        ->fields('s');
      $record= $query->execute()->fetchAssoc();
    }

    $form['term'] = array(
      '#type'=> 'textfield',
      '#title'=>t('Le terme'),
      '#required'=>TRUE,
      '#default_value'=> (isset($record['term']) && $_GET['num']) ? $record['term']:'',
    );

    $form['synonym'] = array(
      '#type'=> 'textfield',
      '#title'=>t('Synonyme'),
      '#required'=>TRUE,
      '#default_value'=> (isset($record['synonym']) && $_GET['num']) ? $record['synonym']:'',
    );

    $form['submit'] = [
      '#type'=> 'submit',
      '#value'=> 'Save',
    ];
    return $form;
  }

  /**
   * @inheritDoc
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    $field= $form_state->getValues();
    $synonym= $field['synonym'];
    $term= $field['term'];
    if (isset($_GET['num'])){
      $field = [
        'term' =>$term,
        'synonym' =>$synonym,
      ];
      $query = Drupal::database();
      $query->update('elasticsearch_synonym')
        ->fields($field)
        ->condition('id', $_GET['num'])
        ->execute();
      drupal_set_message("succesfully updated");
      $form_state->setRedirect('portalis_elasticsearch.synonym_list_route');
    } else {
      $field  = array(
        'term' =>$term,
        'synonym'   =>  $synonym,
      );
      $query = \Drupal::database();
      $query ->insert('elasticsearch_synonym')
        ->fields($field)
        ->execute();
      drupal_set_message("succesfully saved");

      $response = new RedirectResponse("/admin/config/elasticsearch/synonym");
      $response->send();
    }
  }
}
