<?php


namespace Drupal\portalis_elasticsearch\Form;


use Drupal;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

class SynonymDeleteForm extends ConfirmFormBase
{
  /**
   * @inheritDoc
   */
  public function getFormId()
  {
    return 'synonym_delete_fom';
  }

  public $cid;
  /**
   * @inheritDoc
   */
  public function getQuestion()
  {
    return t('Do you want to delete %cid?', array('%cid' => $this->cid));
  }

  /**
   * @inheritDoc
   */
  public function getCancelUrl()
  {
    return new Url('portalis_elasticsearch.synonym_list_route');
  }

  public function getDescription()
  {
    return t('Only do this if you are sure!');
  }

  public function getConfirmText()
  {
    return t('Delete it!');
  }

  public function getCancelText()
  {
    return t('Cancel');
  }

  public function buildForm(array $form, FormStateInterface $form_state, $cid = NULL)
  {
    $this->id = $cid;
    return parent::buildForm($form, $form_state);
  }

  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    parent::validateForm($form, $form_state);
  }
  /**
   * @inheritDoc
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    $query = Drupal::database();
    $query->delete('elasticsearch_synonym')
      ->condition('id', $this->id)
      ->execute();
    drupal_set_message("succesfully deleted");
    $form_state->setRedirect('portalis_elasticsearch.synonym_list_route');
  }

}
