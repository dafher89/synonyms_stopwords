<?php


namespace Drupal\portalis_elasticsearch\Form;

use Drupal;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class StopwordForm.
 *
 * @package Drupal\portalis_elasticsearch\Form
 */
class StopwordForm extends FormBase
{

  /**
   * @inheritDoc
   */
  public function getFormId()
  {
    return 'stopword_form';
  }

  /**
   * @inheritDoc
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {
      $connexion = Database::getConnection();
      $record = array();
     if (isset($_GET['num'])) {
       $query = $connexion->select('elasticsearch_stopword', 's')
         ->condition('id',$_GET['num'])
         ->fields('s');
       $record= $query->execute()->fetchAssoc();
     }

     $form['stopword'] = array(
       '#type'=> 'textfield',
       '#title'=>t('Mot à exclure'),
       '#required'=>TRUE,
       '#default_value'=> (isset($record['stopword']) && $_GET['num']) ? $record['stopword']:'',
     );

     $form['submit'] = [
       '#type'=> 'submit',
       '#value'=> 'Save',
     ];
      return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $field= $form_state->getValues();
    $stopword= $field['stopword'];
    if (isset($_GET['num'])){
      $field = [
        'stopword' =>$stopword,
      ];
      $query = Drupal::database();
      $query->update('elasticsearch_stopword')
        ->fields($field)
        ->condition('id', $_GET['num'])
        ->execute();
      drupal_set_message("succesfully updated");
      $form_state->setRedirect('portalis_elasticsearch.stopword_list_route');
    } else {
      $field  = array(
        'stopword'   =>  $stopword,
      );
      $query = \Drupal::database();
      $query ->insert('elasticsearch_stopword')
        ->fields($field)
        ->execute();
      drupal_set_message("succesfully saved");

      $response = new RedirectResponse("/admin/config/elasticsearch/stopword");
      $response->send();
    }
  }
}
